package handleStrategyTest;

public class ModelTest {
}
