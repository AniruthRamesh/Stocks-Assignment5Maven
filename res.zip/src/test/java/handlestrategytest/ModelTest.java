package handlestrategytest;

/**
 * This class is used to test the model.
 */
public class ModelTest {
}
